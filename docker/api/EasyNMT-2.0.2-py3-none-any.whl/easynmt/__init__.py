__version__ = "2.0.2"
__DOWNLOAD_SERVER__ = 'http://easynmt.net/models/v2'


from .EasyNMT import EasyNMT

